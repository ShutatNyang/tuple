// src/stores/auth.js
import { defineStore } from 'pinia';

export const useAuthStore = defineStore('auth', {
  state: () => ({
    accessToken: sessionStorage.getItem('accessToken') || null, // 인증 토큰 정보
    refreshToken: sessionStorage.getItem('refreshToken') || null,

  }),
  actions: {
    setLoginUser(accessToken, refreshToken) {
      this.accessToken = accessToken; // 로그인 시 accessToken 저장
      this.refreshToken = refreshToken;

      sessionStorage.setItem('accessToken', accessToken);
      sessionStorage.setItem('refreshToken', refreshToken);

    },
    clearLoginUser() {
      this.accessToken = null; // 로그아웃 시 토큰 제거
      this.refreshToken = null;

      sessionStorage.removeItem('accessToken');
      sessionStorage.removeItem('refreshToken');
    },
  },
  getters: {
    // getUserName(state) {
    //   return state.loginUser ? state.loginUser.name : 'Guest'; // 로그인 사용자 이름 반환
    // },
    // isAuthenticated(state) {
    //   return state.isLoggedIn; // 로그인 여부 반환
    // },
  },
});
