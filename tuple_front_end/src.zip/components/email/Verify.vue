<!-- eslint-disable vue/multi-word-component-names -->
<script setup>
import axios from "axios";
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';


const route = useRoute();
const msg = ref('');

function updateMsg(newMsg) {
  msg.value = newMsg;
}

onMounted(async () => {
  try {
    const response = await axios.get(
      "http://localhost/email/verify?token=" + route.query.token
    );

    updateMsg(response.data);

  } catch (error) {

    updateMsg("오류가 발생했습니다.");
    console.error(error);
  }
});
</script>

<template>
  <div>
    <h1>{{ msg }}</h1>
  </div>
</template>

<style scoped>
h1 {
  color: #333;
}
</style>
