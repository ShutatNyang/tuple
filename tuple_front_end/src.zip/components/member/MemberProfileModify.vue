<template>
  <div
    class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden"
    :style="{
      '--checkbox-tick-svg': checkboxTickSvg,
      'font-family': 'Plus Jakarta Sans, Noto Sans, sans-serif',
    }"
  >
    <MemberHeader />
    <div class="layout-container flex h-full grow flex-col">
      <div class="px-40 flex flex-1 justify-center py-5">
        <div
          class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1"
        >
          <h2
            class="text-[#181112] text-lg font-bold leading-tight tracking-[-0.015em] px-4 text-left pb-2 pt-4"
          >
            Edit My Profile
          </h2>

          <!-- 별명 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Nickname
              </p>
              <input
                v-model="nickname"
                type="text"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                placeholder="Enter your nickname"
              />
            </label>
          </div>

          <!-- 폰번호 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Phone Number
              </p>
              <input
                v-model="phone"
                type="text"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                placeholder="Enter your phone number"
              />
            </label>
          </div>

          <!-- 나이 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Age
              </p>
              <input
                v-model="age"
                type="number"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                placeholder="Enter your age"
                min="0"
              />
            </label>
          </div>

          <!-- 자기소개 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Description
              </p>
              <textarea
                v-model="description"
                class="form-input flex w-full min-w-0 flex-1 resize-none rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-28 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                placeholder="Tell us about yourself"
              ></textarea>
            </label>
          </div>

          <!-- 제출 버튼 -->
          <div class="flex px-4 py-3">
            <button
              class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 flex-1 bg-[#fc6986] text-white text-sm font-bold leading-normal tracking-[0.015em]"
              @click.prevent="modifyProfile"
            >
              <span class="truncate">Save Changes</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MemberHeader from "./MemberHeader.vue";
import axios from "axios";

export default {
  components: {
    MemberHeader,
  },
  data() {
    return {
      phone: '',
      nickname: '',
      age: '',
      description: '',
      checkboxTickSvg: `url('data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27rgb(255,255,255)%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e')`,
    };
  },
  mounted() {
    const queryData = this.$route.query.myData;
    if (queryData) {
      try {
        const myData = JSON.parse(queryData);
        console.log("받은 데이터:", myData);

        // myData의 정보를 각각의 데이터 속성에 할당
        this.phone = myData.phone;
        this.nickname = myData.nickname;
        this.age = myData.age;
        this.description = myData.description;
        this.id = myData.id;
        this.email = myData.email;

      } catch (e) {
        console.error("Error parsing myData:", e);
      }
    }
  },
  methods: {
    modifyProfile() {
      const url = "http://localhost/member/modify";
      const accessToken = sessionStorage.getItem("accessToken");
      if (!accessToken) {
        console.error("No access token found in sessionStorage");
        return;
      }

      const headers = {
        Authorization: `Bearer ${sessionStorage.accessToken}`,
      };

      const payload = {
        phone: this.phone,
        nickname: this.nickname,
        age: this.age,
        description: this.description,
        id: this.id,
        email : this.email,
      };

      axios
        .post(url, payload, { headers })
        .then((response) => {
          console.log("Profile modified successfully", response);
          if (response.status == 200) {
            alert("수정에 성공 했습니다.");
            this.$router.push('/member/profile');
          }
        })
        .catch((error) => {
          console.error("Error modifying profile", error);
        });
    },
  },
};
</script>
