<template>
  <div
    class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden"
    :style="{
      '--checkbox-tick-svg': checkboxTickSvg,
      'font-family': 'Plus Jakarta Sans, Noto Sans, sans-serif',
    }"
  >
    <MemberHeader />
    <div class="layout-container flex h-full grow flex-col">
      <div class="px-40 flex flex-1 justify-center py-5">
        <div
          class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1"
        >
        <h3 class="text-[#111418] tracking-light text-2xl font-bold leading-tight px-4 text-center pb-2 pt-5">Create an account</h3>
          <form @submit.prevent="signUp">
            <div class="px-120 flex flex-1 justify-center py-5">
              <div class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1">

                <!-- 이메일 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">ID (email)</p>
                    <div class="flex w-full gap-2">
                      <input
                        class="form-input flex w-3/4 min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                        v-model="email"
                        placeholder="example@example.com"
                      />
                      <button
                        type="button"
                        class="w-1/4 bg-[#9e4759] hover:bg-[#8d2c3d] text-white font-medium rounded-xl h-14 text-base"
                        @click="checkDuplicate"
                      >
                        중복확인
                      </button>
                    </div>
                    <!-- 에러 또는 성공 메시지 -->
                    <p
                      v-if="emailError"
                      :class="emailError.includes('중복된') ? 'text-red-500' : 'text-blue-500'"
                      class="text-sm mt-2"
                    >
                      {{ emailError }}
                    </p>
                  </label>
                </div>



                <!-- 비밀번호 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Password</p>
                    <input
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="password"
                      placeholder="password"
                      type="password"
                    />
                  </label>
                </div>

                <!-- 이름 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Name</p>
                    <input
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="name"
                      placeholder="Full Name"
                    />
                  </label>
                </div>

                <!-- 닉네임 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Nickname</p>
                    <input
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="nickname"
                      placeholder="Nickname"
                    />
                  </label>
                </div>

                <!-- 전화번호 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Phone number</p>
                    <input
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="phone"
                      placeholder="Phone number"
                    />
                  </label>
                </div>

                <!-- 나이 입력 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Age</p>
                    <input
                      type="number"
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="age"
                      placeholder="Enter your age"
                      min="0"
                      max="120"
                    />
                  </label>
                </div>


                <!-- 성별 선택 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">Gender</p>
                    <select
                      class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-14 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="gender"
                    >
                      <option value="">Select your gender</option>
                      <option v-for="(option, index) in genderOptions" :key="index" :value="option">{{ option }}</option>
                    </select>
                  </label>
                </div>

                <!-- 자기 소개 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <label class="flex flex-col min-w-40 flex-1">
                    <p class="text-[#1c0d10] text-base font-medium leading-normal pb-2">자기 소개</p>
                    <textarea
                      class="form-input flex w-full min-w-0 flex-1 resize-none rounded-xl text-[#1c0d10] focus:outline-0 focus:ring-0 border-none bg-[#f4e6e9] focus:border-none h-28 placeholder:text-[#9e4759] p-4 text-base font-normal leading-normal"
                      v-model="description"
                      placeholder="자기 소개(선택)"
                    ></textarea>
                  </label>
                </div>


                <!-- 제출 버튼 -->
                <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
                  <button
                    type="submit"
                    class="w-full bg-[#9e4759] hover:bg-[#8d2c3d] text-white font-medium rounded-xl h-14 text-xl"
                  >
                    Create Account
                  </button>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import MemberHeader from "./MemberHeader.vue";
import axios from "axios";

export default {
  components: {
    MemberHeader,
  },
  data() {
  return {
    email: '',
    emailError: '',
    emailDupl : 0,
    password: '',
    name: '',
    nickname: '',
    phone: '',
    age: '',
    gender: '',
    ageOptions: ['Under 18', '18-25', '26-35', '36-50', '51+'],
    genderOptions: ['Male', 'Female', 'Other'],
    description: "",
  };
},
  methods: {
    // 데이터를 URL-encoded 형식으로 변환
    toUrlEncoded(data) {
      return Object.keys(data)
        .map((key) => `${encodeURIComponent(key)}=${encodeURIComponent(data[key])}`)
        .join("&");
    },
    async signUp() {
      if (this.emailDupl !== 2) {
        alert("이메일 입력을 확인해주세요");
        return;
      }
      if (this.password === '') {
        alert("비밀번호는 필수 입니다.");
        return;
      }
      console.log("회원가입 데이터:", {
        email: this.email,
        password: this.password,
        name: this.name,
        phone: this.phone,
        nickname: this.nickname,
        age: this.age,
        gender: this.gender,
        description : this.description,
      });

      const memberData = {
        email: this.email.trim(),
        password: this.password.trim(),
        name: this.name.trim(),
        phone: this.phone.trim(),
        nickname: this.nickname.trim(),
        age: this.age,
        gender: this.gender,
        description : this.description,
      };

      try {
        const response = await axios.post(
          "http://localhost/member/regist",
          this.toUrlEncoded(memberData), // 데이터 URL-encoded 형식으로 변환
          {
            headers: {
              "Content-Type": "application/x-www-form-urlencoded",
            },
          }
        );

        if (response.status === 200) {
          alert("회원가입이 성공적으로 완료되었습니다.");
          window.location.href = "http://localhost:5173/member/login";
        }
      } catch (error) {
        console.error("회원가입 요청 실패:", error.response || error);
        alert("회원가입에 실패했습니다. 다시 시도해주세요.");
      }
    },
    async checkDuplicate() {
      if (!this.email.trim()) {
        this.emailDupl = 0;
        this.emailError = "이메일을 입력해주세요.";
        return;
      }

      try {
        const response = await axios.get(`http://localhost/member/idCheck/` + this.email.trim());
        if (response.data.bool) {
          this.emailError = "중복된 아이디 입니다.";
          this.emailDupl = 1;
        } else {
          this.emailError = "사용 가능한 아이디 입니다.";
          this.emailDupl = 2;
        }
      } catch (error) {
        console.error("중복확인 요청 실패:", error.response || error);
        this.emailError = "중복확인 중 문제가 발생했습니다. 다시 시도해주세요.";
      }
    },

  },
};
</script>
