<template>
  <div
    class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden"
    :style="{
      '--checkbox-tick-svg': checkboxTickSvg,
      'font-family': 'Plus Jakarta Sans, Noto Sans, sans-serif',
    }"
  >
    <MemberHeader />
    <div class="layout-container flex h-full grow flex-col">
      <div class="px-40 flex flex-1 justify-center py-5">
        <div
          class="layout-content-container flex flex-col w-[512px] max-w-[512px] py-5 max-w-[960px] flex-1"
        >
          <h2
            class="text-[#181112] text-lg font-bold leading-tight tracking-[-0.015em] px-4 text-left pb-2 pt-4"
          >
            My Profile
          </h2>

          <!-- 별명 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Nickname
              </p>
              <input
                v-model="nickname"
                type="text"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                readonly
              />
            </label>
          </div>

          <!-- 폰번호 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Phone Number
              </p>
              <input
                v-model="phone"
                type="text"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                readonly
              />
            </label>
          </div>

          <!-- 나이 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Age
              </p>
              <input
                v-model="age"
                type="number"
                class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-14 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                readonly
              />
            </label>
          </div>

          <!-- 자기소개 -->
          <div class="flex max-w-[480px] flex-wrap items-end gap-4 px-4 py-3">
            <label class="flex flex-col min-w-40 flex-1">
              <p class="text-[#181112] text-base font-medium leading-normal pb-2">
                Description
              </p>
              <textarea
                v-model="description"
                class="form-input flex w-full min-w-0 flex-1 resize-none rounded-xl text-[#181112] focus:outline-0 focus:ring-0 border border-[#e6dbdd] bg-white focus:border-[#e6dbdd] h-28 placeholder:text-[#8c5f68] p-[15px] text-base font-normal leading-normal"
                readonly
              ></textarea>
            </label>
          </div>

          <!-- 수정 버튼 -->
          <div class="flex px-4 py-3">
            <button
              class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 flex-1 bg-[#fc6986] text-white text-sm font-bold leading-normal tracking-[0.015em]"
              @click.prevent="goProfileModify(myData)"
            >
              <span class="truncate">정보 수정</span>
            </button>
          </div>


          <!-- 비밀번호 재설정 버튼 -->
          <div class="flex px-4 py-3">
            <button
              class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 flex-1 bg-[#fc6986] text-white text-sm font-bold leading-normal tracking-[0.015em]"
              @click.prevent="goUpdatePassword(myData.email)"
            >
              <span class="truncate">비밀 번호 재설정</span>
            </button>
          </div>

          <!-- 삭제 버튼 -->
          <div class="flex px-4 py-3">
            <button
              class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 flex-1 bg-[#f5f0f1] text-[#181112] text-sm font-bold leading-normal tracking-[0.015em]"
              @click.prevent="deleteMember"
            >
              <span class="truncate">계정 탈퇴</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import MemberHeader from "./MemberHeader.vue";
import { useAuthStore } from "@/stores/auth";

export default {
  components: {
    MemberHeader,
  },
  data() {
    return {
      userId: "",
      phone: "",
      nickname: "",
      age: null,
      description: "",
      email: "",
      checkboxTickSvg: `url('data:image/svg+xml,%3csvg viewBox=%270 0 16 16%27 fill=%27rgb(255,255,255)%27 xmlns=%27http://www.w3.org/2000/svg%27%3e%3cpath d=%27M12.207 4.793a1 1 0 010 1.414l-5 5a1 1 0 01-1.414 0l-2-2a1 1 0 011.414-1.414L6.5 9.086l4.293-4.293a1 1 0 011.414 0z%27/%3e%3c/svg%3e')`,
      myData: {},
    };
  },
  mounted() {
    const token = sessionStorage.getItem("accessToken");
    if (token && token !== "") {
      this.getMemberInfo(token);
    } else {
      console.log("잘못된 접근입니다.");
      alert("로그인이 필요합니다.");
      this.$router.push("/login"); // 로그인 페이지로 이동
    }
  },
  methods: {
    // 회원 정보 요청
    async getMemberInfo(token) {
      const url = "http://localhost/member/getMemberInfo"; // 요청 보낼 URL

      try {
        const response = await axios.post(
          url,
          {},
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: "Bearer " + token,
            },
          }
        );

        // 서버에서 받은 데이터를 상태에 저장
        const data = response.data;
        console.log("회원 정보:", data);
        this.id = data.id;
        this.phone = data.phone;
        this.nickname = data.nickname;
        this.age = data.age;
        this.description = data.description;
        this.email = data.email;

        this.myData = {
          id : this.id,
          phone: this.phone,
          nickname: this.nickname,
          age: this.age,
          description: this.description,
          email : this.email,
        }

      } catch (error) {
        console.log(error.response.status);
        if (error.response.status === 401) {

          console.log("Access Token 만료. Refresh Token으로 재시도합니다.");
          const newAccessToken = await this.refreshAccessToken();
          console.log(newAccessToken);

          if (newAccessToken) {
            console.log("새 Access Token:", newAccessToken);

            await this.getMemberInfo(newAccessToken);
          } else {
            console.error("Access Token 갱신 실패");
            alert("로그인이 필요합니다.");
            this.$router.push("/login");
          }
        } else {
          console.error("회원 정보를 가져오는 데 실패했습니다.");
          alert("회원 정보를 가져오지 못했습니다.");
        }
      }
    },

    goProfileModify(myData) {
      console.log(myData);
      this.$router.push({
        path: '/member/modify',
        query: {
          myData: JSON.stringify(myData),
        }
      });
    },

    async refreshAccessToken() {
      const url = "http://localhost/member/refresh";
      const refreshToken = sessionStorage.getItem("refreshToken");

      if (!refreshToken) {
        console.error("Refresh Token이 없습니다.");
        return null;
      }

      try {
        const response = await axios.post(
          url,
          {},
          {
            headers: {
              "Content-Type": "application/json",
              "refreshToken": refreshToken
            },
          },
        );

        const newAccessToken = response.data.accessToken;

        sessionStorage.setItem("accessToken", newAccessToken);

        return newAccessToken;

      } catch (error) {
        console.error("Access Token 갱신 중 에러 발생:", error);
        return null;
      }
    },

    async deleteMember() {
        const userConfirmed = confirm("정말로 계정을 탈퇴하시겠습니까? 이 작업은 취소할 수 없습니다.");
        if (!userConfirmed) return;

        const token = sessionStorage.getItem("accessToken");
        if (!token) {
            alert("로그인이 필요합니다.");
            this.$router.push("/login");
        }

        const url = "http://localhost/member/delete";

        try {
            const response = await axios.post(
                url,
                null,
                {
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: "Bearer " + token,
                    },
                    params: { email: this.email },
                }
            );

            if (response.status === 200) {
                alert("회원 탈퇴에 성공했습니다.");

                const authStore = useAuthStore();
                authStore.clearLoginUser();

                sessionStorage.removeItem("accessToken");
                sessionStorage.removeItem("refreshToken");

              location.href = 'http://localhost:5173/';
            }
        } catch (error) {
            if (error.response?.status === 403) {
              alert(`회원 탈퇴 실패: ${error.response.data}`);
            } else {
              alert("회원 탈퇴 중 문제가 발생했습니다.");
            }
        }
    },
    async goUpdatePassword(email) {
      if (!email) {
        alert("이메일 정보를 가져올 수 없습니다.");
        return;
      }

      const url = "http://localhost/email/send-reset-password";
      try {
        const response = await axios.post(
          url,
          null,
          {
            params: { email },
            headers: {
              "Content-Type": "application/json",
            },
          }
        );

        if (response.status === 200) {
          alert("비밀번호 변경 이메일이 전송되었습니다.");
        }
      } catch (error) {
        console.error("비밀번호 변경 이메일 전송 실패:", error);
        alert(
          error.response?.data?.message ||
          "비밀번호 변경 이메일 전송 중 문제가 발생했습니다."
        );
      }
    },
  },
};
</script>

<style>
</style>
