<script setup>

</script>

<template>
  <div>
    mk plan view
  </div>
</template>

<style scoped>

</style>
