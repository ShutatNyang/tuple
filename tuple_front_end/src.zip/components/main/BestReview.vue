<template>
  <div class="px-10 flex flex-1 justify-center py-5">
    <div class="layout-content-container flex flex-col max-w-[960px] flex-1">
      <!-- 제목 -->
      <h2
        class="text-[#181013] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5"
      >
        베스트 후기
      </h2>

      <!-- 게시물 리스트 -->
      <div class="p-4" v-for="(review, index) in bestReview" :key="index">
        <ImageBoardItem
          :title="review.title"
          :time="review.time"
          :imageUrl="review.imageUrl"
          :location="review.location"
        />
      </div>
    </div>
  </div>
</template>

<script>
import ImageBoardItem from "../board/item/ImageBoardItem.vue";

export default {
  components: {
    ImageBoardItem,
  },
  //   data() {
  //   return {
  //     bestReview: [
  //       {
  //         title: "Brewery Tour and Tasting",
  //         time: "Saturday, 2pm - 4pm",
  //         imageUrl: "https://cdn.usegalileo.ai/sdxl10/304e8657-3722-4624-a591-8bc131efe877.png",
  //         location: "Portland, OR",
  //       },
  //       {
  //         title: "Guided Street Art Tour",
  //         time: "Friday, 11am - 1pm",
  //         imageUrl: "https://cdn.usegalileo.ai/sdxl10/9c4dadb4-4659-4f7e-8e90-14f35db79240.png",
  //         location: "Los Angeles, CA",
  //       },
  //       {
  //         title: "Wine Tasting Experience",
  //         time: "Sunday, 1pm - 3pm",
  //         imageUrl: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38",
  //         location: "Napa Valley, CA",
  //       },
  //       {
  //         title: "Historical Walking Tour",
  //         time: "Monday, 10am - 12pm",
  //         imageUrl: "https://images.unsplash.com/photo-1533577116850-9cc66cad8a9b",
  //         location: "Boston, MA",
  //       },
  //       {
  //         title: "Art Gallery Opening",
  //         time: "Wednesday, 6pm - 9pm",
  //         imageUrl: "https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0",
  //         location: "New York, NY",
  //       },
  //     ],
  //   };
  // }
};
</script>

<style scoped>
.layout-content-container {
  display: flex;
  flex-direction: column;
  max-width: 960px;
  flex: 1;
  margin: 0 auto;
}
.p-4 {
  padding: 16px; /* 적절한 패딩을 추가 */
}
</style>
