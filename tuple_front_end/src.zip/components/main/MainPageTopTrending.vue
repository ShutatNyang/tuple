<template>
  <section>
    <h2 class="text-[#181013] text-[22px] font-bold leading-tight tracking-[-0.015em] px-4 pb-3 pt-5">
      인기 관광지
    </h2>
    <div class="grid grid-cols-[repeat(auto-fit,minmax(158px,1fr))] gap-3 p-4">
      <MainPageTopTrendingCard
        v-for="(place, index) in topTrending"
        :key="index"
        :place="place"
      />
    </div>
  </section>
</template>

<script>
import MainPageTopTrendingCard from './MainPageTopTrendingCard.vue';

export default {
  components: { MainPageTopTrendingCard },
  data() {
    return {
      topTrending: [
        {
          name: 'Trending Place 1',
          info: 'Explore the best!',
          image: 'https://cdn.usegalileo.ai/stability/38f12f05-0383-4d21-a361-06d68fcaaa52.png',
        },
        {
          name: 'Trending Place 2',
          info: 'Great place for relaxation.',
          image: 'https://cdn.usegalileo.ai/sdxl10/a3c17fe7-ec82-416f-8f02-c615cba2ba89.png',
        },
        {
          name: 'Trending Place 3',
          info: 'Perfect for families.',
          image: 'https://cdn.usegalileo.ai/sdxl10/e24cb525-0c6e-4b7f-b3eb-daa6eaeffdf9.png',
        },
        {
          name: 'Trending Place 4',
          info: 'A must-visit location.',
          image: 'https://cdn.usegalileo.ai/stability/fccacc81-7c8d-4f07-866c-eb24ee33a72a.png',
        },
      ],
    };
  },
};
</script>
