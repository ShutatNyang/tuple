<template>
  <div
    class="relative flex size-full min-h-screen flex-col bg-white group/design-root overflow-x-hidden"
    :style="{ fontFamily: 'Plus Jakarta Sans, Noto Sans, sans-serif' }"
  >
    <div class="layout-container flex h-full grow flex-col">
      <div class="flex flex-1 justify-center items-center py-5" id="pink">
        <div
          class="layout-content-container flex flex-col w-full max-w-[960px] flex-1"
          id="white"
        >
          <!-- Hero Section -->
          <HeroSection />

          <!-- Featured Destinations Section -->
          <FeaturedDestinations :featuredDestinations="featuredDestinations" />

          <!-- Top Trending Section -->
          <TopTrending :topTrending="topTrending" />

          <!-- Explore By Interest Section -->
          <BestReview :BestReview="bestReview" />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import HeroSection from "../main/HeroSection.vue";
import FeaturedDestinations from "../main/MainPageMatch.vue";
import TopTrending from "../main/MainPageTopTrending.vue";
import BestReview from "../main/BestReview.vue";

export default {
  props: {
    activeSection: {
      type: String,
      required: true,
    },
  },
  components: {
    HeroSection,
    FeaturedDestinations,
    TopTrending,
    BestReview,
  },
};
</script>

<style scoped>
#top-trending {
  padding: 1rem;
  background-color: #f9f9f9;
  border-radius: 8px;
}
#pink {
  background-color: #f0dbe2;
}
#white {
  background-color: #fff;
  border-radius: 3%;
}
</style>
