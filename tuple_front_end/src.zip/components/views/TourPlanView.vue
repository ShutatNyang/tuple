<template>
  <div class="relative flex size-full min-h-screen flex-col bg-white overflow-x-hidden">
    <div class="layout-container flex h-full grow flex-col">
      <div class="flex flex-1 justify-center py-5" id="pink">
        <div
          class="layout-content-container flex flex-col w-full max-w-[960px] flex-1"
          id="white"
        >
          <!-- 탭 -->
          <TourPlanTab @tab-changed="handleTabChange" />

          <!-- 로딩 상태 -->
          <div v-if="loading" class="text-center mt-10">Loading...</div>

          <!-- 에러 상태 -->
          <div v-else-if="error" class="text-center mt-10 text-red-600">
            {{ error }}
          </div>

          <!-- Plan List -->
          <PlanList v-else :plans="activeTab === 'my-plan' ? myPlans : plans" />
          <div class="flex justify-end mt-5">
            <MakePlanButton />
          </div>
        </div>

      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import TourPlanTab from "../tour-plan/TourPlanTab.vue";
import PlanList from "../tour-plan/PlanList.vue";
import MakePlanButton from "../tour-plan/item/MakePlanButton.vue";

export default {
  name: "TourPlanView",
  components: {
    TourPlanTab,
    PlanList,
    MakePlanButton,
  },
  data() {
    return {
      plans: [], // 전체 플랜 데이터를 저장
      myPlans: [], // 필터링된 플랜 (내 플랜)
      accessToken: sessionStorage.getItem("accessToken"), // 토큰 가져오기
      myEmail: "", // 내 이메일
      myId: "", // 내 ID
      activeTab: "my-plan", // 활성화된 탭 상태
    };
  },
  methods: {
    handleTabChange(tab) {
      // 탭 변경 이벤트 처리
      this.activeTab = tab;
    },
  },
  async mounted() {
    try {
      // 전체 플랜 데이터 가져오기
      const response = await axios.post("http://localhost/tour-plan/list/all", null, null);
      console.log("플랜 데이터:", response.data);
      this.plans = response.data;

      // 이메일 가져오기
      const emailResponse = await axios.post(
        "http://localhost/member/getEmailFromToken",
        null,
        {
          headers: {
            "Content-Type": "application/json",
            "accessToken": this.accessToken, // 헤더에 accessToken 추가
          },
        }
      );
      this.myEmail = emailResponse.data;
      console.log("이메일 데이터:", emailResponse.data);

      // 내 ID 가져오기
      const idResponse = await axios.post("http://localhost/member/getMemberIdFromEmail?email=" + this.myEmail);
      this.myId = idResponse.data;
      console.log("내 ID:", idResponse.data);

      // ownerId와 myId가 같은 항목 필터링
      this.myPlans = this.plans.filter(plan => plan.ownerId === this.myId);
      console.log("내 플랜:", this.myPlans);
    } catch (error) {
      console.error("데이터를 불러오는 데 실패했습니다:", error);
    }
  },
};
</script>

<style scoped>
#pink {
  background-color: #f0dbe2;
  display: flex;
  justify-content: center;
  align-items: center;
}

#white {
  background-color: #fff;
  border-radius: 3%;
  padding: 20px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  max-width: 960px;
  width: 100%;
}
</style>
