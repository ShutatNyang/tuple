<!-- src/components/board/EventBoardItem.vue -->
<template>
  <div
    class="flex items-stretch justify-between gap-4 rounded-xl border border-gray-400 my-2 p-2 cursor-pointer"
    @click="goToDetail"
  >
    <!-- 텍스트 섹션 -->
    <div class="flex flex-[2_2_0px] flex-col gap-4">
      <div class="flex flex-col gap-1">
        <p class="text-[#181013] text-base font-bold leading-tight">
          {{ item.title }}
        </p>
        <p class="text-[#8d5e6d] text-sm font-normal leading-normal">
          {{ item.email }} / {{ item.registTime }}
        </p>
        <p class="text-[#8d5e6d] text-sm font-normal leading-normal">
          추천 : {{ item.likeCount }} 비추천
          {{ item.dislikeCount }}
        </p>
      </div>
    </div>
    <!-- 이미지 섹션 -->
    <div
      class="flex-1 bg-center bg-no-repeat aspect-video bg-cover rounded-xl"
      :style="{ backgroundImage: `url(${imageUrl})` }"
    ></div>
  </div>
</template>

<script>
import { useRouter } from "vue-router";

export default {
  name: "ImageBoardItem",
  props: {
    item: {
      type: Object,
      required: true,
    },
    boardName: {
      type: String,
      required: true, // 부모에서 전달받은 boardName
    },
  },
  setup(props) {
    const router = useRouter();
    const goToDetail = () => {
      router.push(`/board/${props.boardName}/detail/${props.item.id}`);
    };

    return {
      goToDetail,
    };
  },
};
</script>

<style scoped>
.cursor-pointer {
  cursor: pointer; /* 클릭 가능 표시 */
}
</style>
