<template>
  <div>
    <!-- Pagination Centered -->
    <div class="flex items-center justify-center px-4">
      <div class="flex gap-2">
        <a
          href="#"
          class="flex size-10 items-center justify-center"
          @click.prevent="prevPage"
        >
          <div
            class="text-[#181112]"
            data-icon="CaretLeft"
            data-size="18px"
            data-weight="regular"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18px"
              height="18px"
              fill="currentColor"
              viewBox="0 0 256 256"
            >
              <path
                d="M165.66,202.34a8,8,0,0,1-11.32,11.32l-80-80a8,8,0,0,1,0-11.32l80-80a8,8,0,0,1,11.32,11.32L91.31,128Z"
              ></path>
            </svg>
          </div>
        </a>

        <a
          v-for="page in totalPages"
          :key="page"
          href="#"
          class="text-sm flex size-10 items-center justify-center rounded-full"
          :class="{
            'font-bold bg-[#f5f0f1]': page === currentPage,
            'font-normal': page !== currentPage,
          }"
          @click.prevent="goToPage(page)"
        >
          {{ page }}
        </a>

        <a
          href="#"
          class="flex size-10 items-center justify-center"
          @click.prevent="nextPage"
        >
          <div
            class="text-[#181112]"
            data-icon="CaretRight"
            data-size="18px"
            data-weight="regular"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="18px"
              height="18px"
              fill="currentColor"
              viewBox="0 0 256 256"
            >
              <path
                d="M181.66,133.66l-80,80a8,8,0,0,1-11.32-11.32L164.69,128,90.34,53.66a8,8,0,0,1,11.32-11.32l80,80A8,8,0,0,1,181.66,133.66Z"
              ></path>
            </svg>
          </div>
        </a>
      </div>
    </div>

    <!-- Write Button Aligned Right -->
    <div class="flex justify-end px-4 py-2">
      <button
        class="flex min-w-[84px] max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-xl h-10 px-4 bg-[#fc6986] text-white text-sm font-bold leading-normal tracking-[0.015em]"
        @click="goToWritePage"
      >
        <span class="truncate">Write</span>
      </button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      currentPage: 1,
      totalPages: 5, // 총 페이지 수를 필요에 따라 조정하세요
    };
  },
  computed: {
    currentBoardName() {
      return this.$route.name.replace("BoardItem", "").toLowerCase(); // 현재 라우트 이름에서 boardName 추출
    },
  },
  methods: {
    goToWritePage() {
      this.$router.push(`/board/${this.currentBoardName}/write`);
    },
    prevPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    },
    nextPage() {
      if (this.currentPage < this.totalPages) {
        this.currentPage++;
      }
    },
    goToPage(page) {
      this.currentPage = page;
    },
  },
};
</script>

<style scoped>
/* Tailwind 기본 스타일을 사용 중이므로 추가 스타일 필요 시 작성 */
</style>
