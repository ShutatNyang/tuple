<template>
  <div id="app">
    <HeaderNav />
    <RouterView />
    <!-- 라우터 뷰 추가 -->
  </div>
</template>

<script>
import HeaderNav from "@/components/main/HeaderNav.vue";

export default {
  name: "App",
  components: {
    HeaderNav,
  },
};
</script>

<style>
/* 글로벌 스타일 */
html,
body,
#app {
  margin: 0;
  padding: 0;
  font-family: "Plus Jakarta Sans", "Noto Sans", sans-serif;
  background-color: #fff;
  color: #181013;
  overflow-x: hidden;
}
</style>
