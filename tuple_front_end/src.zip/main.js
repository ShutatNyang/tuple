import { createPinia } from "pinia";
import { createApp } from "vue";

// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.min.css";
// Bootstrap JavaScript (필요한 경우에만 사용)
import "bootstrap/dist/js/bootstrap.bundle.min.js";

import "./assets/tailwind.css";

import App from "./App.vue";
import router from "./router";

const app = createApp(App);

app.use(createPinia());
app.use(router);

app.mount("#app");
